import { Module } from '@nestjs/common';
import { ConnectorsController } from './connectors.controller';
import { ConnectorsService } from './connectors.service';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [ConnectorsController],
  providers: [ConnectorsService, PrismaService],
})
export class ConnectorsModule {}
