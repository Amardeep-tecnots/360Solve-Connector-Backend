import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { CreateConnectorDto } from './dto/create-connector.dto';
import { UpdateConnectorDto } from './dto/update-connector.dto';
import { ConnectorQueryDto } from './dto/connector-query.dto';
import { HeartbeatDto } from './dto/heartbeat.dto';
import { randomBytes } from 'crypto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class ConnectorsService {
  constructor(private prisma: PrismaService) {}

  async create(tenantId: string, dto: CreateConnectorDto) {
    // Generate API Key for Mini Connectors
    let apiKey: string | undefined;
    let apiKeyHash: string | undefined;
    let apiKeyPrefix: string | undefined;

    if (dto.type === 'MINI') {
      apiKey = `vmc_${randomBytes(24).toString('hex')}`;
      apiKeyPrefix = apiKey.substring(0, 8);
      apiKeyHash = await bcrypt.hash(apiKey, 10);
    }

    const connector = await this.prisma.connector.create({
      data: {
        tenantId,
        name: dto.name,
        type: dto.type,
        networkAccess: dto.networkAccess,
        supportedAggregators: dto.supportedAggregators || [],
        apiKeyHash,
        apiKeyPrefix,
        status: 'OFFLINE', // Initial status
      },
    });

    return { ...connector, apiKey }; // Return API key only once
  }

  async findAll(tenantId: string, query: ConnectorQueryDto) {
    const { status, type, search } = query;
    const where: any = { tenantId };

    if (status) where.status = status;
    if (type) where.type = type;
    if (search) {
      where.name = { contains: search, mode: 'insensitive' };
    }

    return this.prisma.connector.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string, tenantId: string) {
    const connector = await this.prisma.connector.findFirst({
      where: { id, tenantId },
    });

    if (!connector) {
      throw new NotFoundException(`Connector with ID "${id}" not found`);
    }

    return connector;
  }

  async update(id: string, tenantId: string, dto: UpdateConnectorDto) {
    await this.findOne(id, tenantId); // Verify existence

    return this.prisma.connector.update({
      where: { id },
      data: dto,
    });
  }

  async remove(id: string, tenantId: string) {
    await this.findOne(id, tenantId); // Verify existence

    return this.prisma.connector.delete({
      where: { id },
    });
  }

  async heartbeat(id: string, dto: HeartbeatDto) {
    // Note: In a real scenario, we might need to verify the API key here or use a specific Guard
    // For now, we update based on ID
    
    return this.prisma.connector.update({
      where: { id },
      data: {
        lastHeartbeat: new Date(),
        status: 'ONLINE',
        ...dto,
      },
    });
  }
}
