import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags, ApiResponse } from '@nestjs/swagger';
import { ConnectorsService } from './connectors.service';
import { CreateConnectorDto } from './dto/create-connector.dto';
import { UpdateConnectorDto } from './dto/update-connector.dto';
import { ConnectorQueryDto } from './dto/connector-query.dto';
import { ConnectorListResponseDto, ConnectorResponseDto } from './dto/connector-response.dto';
import { HeartbeatDto } from './dto/heartbeat.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { TenantMemberGuard } from '../common/guards/tenant-member.guard';
import { TenantId } from '../common/decorators/tenant-id.decorator';

@Controller('api/connectors')
@ApiTags('Connectors')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantMemberGuard)
export class ConnectorsController {
  constructor(private readonly connectorsService: ConnectorsService) {}

  @Post()
  @ApiResponse({ status: 201, type: ConnectorResponseDto })
  async create(
    @TenantId() tenantId: string,
    @Body() createConnectorDto: CreateConnectorDto,
  ) {
    const result = await this.connectorsService.create(tenantId, createConnectorDto);
    return { success: true, data: result };
  }

  @Get()
  @ApiResponse({ status: 200, type: ConnectorListResponseDto })
  async findAll(
    @TenantId() tenantId: string,
    @Query() query: ConnectorQueryDto,
  ) {
    const data = await this.connectorsService.findAll(tenantId, query);
    return { success: true, data };
  }

  @Get(':id')
  @ApiResponse({ status: 200, type: ConnectorResponseDto })
  async findOne(
    @Param('id') id: string,
    @TenantId() tenantId: string,
  ) {
    const data = await this.connectorsService.findOne(id, tenantId);
    return { success: true, data };
  }

  @Put(':id')
  @ApiResponse({ status: 200, type: ConnectorResponseDto })
  async update(
    @Param('id') id: string,
    @TenantId() tenantId: string,
    @Body() updateConnectorDto: UpdateConnectorDto,
  ) {
    const data = await this.connectorsService.update(id, tenantId, updateConnectorDto);
    return { success: true, data };
  }

  @Delete(':id')
  async remove(
    @Param('id') id: string,
    @TenantId() tenantId: string,
  ) {
    await this.connectorsService.remove(id, tenantId);
    return { success: true };
  }

  @Post(':id/heartbeat')
  @ApiResponse({ status: 200, type: ConnectorResponseDto })
  async heartbeat(
    @Param('id') id: string,
    @Body() heartbeatDto: HeartbeatDto,
  ) {
    const data = await this.connectorsService.heartbeat(id, heartbeatDto);
    return { success: true, data };
  }
}
